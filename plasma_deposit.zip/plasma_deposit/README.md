## Plasma Deposit Soft

### описание
софт для аппрува USDT/USDC и депозита в Plasma

---

### настройка

1. в папке `input_data` заполнить `privatekeys.txt` и `proxies.txt`
2. в `settings.py` укажите свои данные и настройки (*тг бот, настройки депозита*)

---

### запуск

1. установить необходимые либы `pip install -r requirements.txt`
2. запустить софт `py main.py`
3. создать базу данных (*Create Database -> New Database*)
4. стартуем необходимый режим

---

[🍭 kAramelniy 🍭](https://t.me/kAramelniy)

---
