from random import randint
from loguru import logger
from time import sleep
import asyncio
import os

from modules.utils import choose_mode
from modules.retry import DataBaseError
from modules import *

from settings import SLEEP_AFTER_ACC, THREADS


async def run_modules(
        mode: int,
        module_data: dict,
        monitor: TotalSupplyMonitor,
        sem: asyncio.Semaphore,
        active_wallets: asyncio.Queue,
):
    async with sem:
        try:
            await active_wallets.get()

            wallet = Wallet(
                privatekey=module_data["privatekey"],
                encoded_pk=module_data["encoded_privatekey"],
                recipient=module_data["recipient"],
                db=db,
            )
            logger.info(f'[•] Web3 | {wallet.address}')

            module_data["module_info"]["status"] = await Plasma(wallet=wallet).run(mode=mode, monitor=monitor)

        except DataBaseError:
            module_data = None
            raise

        except Exception as err:
            logger.error(f'[-] Web3 | {wallet.address} | {err}')
            db.append_report(privatekey=wallet.encoded_pk, text=str(err), success=False)

        finally:
            if type(module_data) == dict:
                db.remove_module(module_data=module_data)

                if module_data['last']:
                    reports = db.get_account_reports(privatekey=wallet.encoded_pk)
                    await TgReport().send_log(logs=reports)

                if (
                        module_data["module_info"]["status"] is True and
                        not active_wallets.empty()
                ):
                    await asyncio.sleep(randint(*SLEEP_AFTER_ACC))

                active_wallets.task_done()


async def runner(mode: int):
    RPCInitializer(proxies=db.proxies)
    sem = asyncio.Semaphore(THREADS)

    all_modules = db.get_all_modules()
    active_wallets = asyncio.Queue()
    for _ in all_modules:
        await active_wallets.put(None)

    if all_modules != 'No more accounts left':
        monitor = TotalSupplyMonitor(
            total_accs=len(all_modules),
            max_supply=1_000_000_000,
            decimals=6
        )
        if mode == 1:
            asyncio.create_task(monitor.run())

        await asyncio.gather(*[
            run_modules(
                mode=mode,
                module_data=module_data,
                monitor=monitor,
                sem=sem,
                active_wallets=active_wallets,
            )
            for module_data in all_modules
        ])

    logger.success(f'All accounts done.')
    return 'Ended'


if __name__ == '__main__':
    if os.name == "nt":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    try:
        db = DataBase()

        while True:
            mode = choose_mode()

            match mode.type:
                case "database":
                    db.create_modules(mode=mode.soft_id)

                case "module":
                    if asyncio.run(runner(mode=mode.soft_id)) == 'Ended': break
                    print('')

        sleep(0.1)
        input('\n > Exit\n')

    except DataBaseError as e:
        logger.error(f'[-] Database | {e}')

    except KeyboardInterrupt:
        pass

    finally:
        logger.info('[•] Soft | Closed')
