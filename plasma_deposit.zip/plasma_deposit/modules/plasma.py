from random import uniform, randint
from loguru import logger
import asyncio

from .wallet import Wallet
from .retry import TransactionError
from .utils import find_contract_error
from .rpc_initializer import RPCInitializer
from settings import (
    TOKENS_TO_DEPOSIT,
    DEPOSIT_PERCENT,
    THREADS
)


VAULT_ADDRESS: str = "0xd1074E0AE85610dDBA0147e29eBe0D8E5873a000"
VAULT_ABI: str = '[{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}]'

DEPOSIT_ADDRESS: str = "0x4E7d2186eB8B75fBDcA867761636637E05BaeF1E"
DEPOSIT_ABI: str = '[{"inputs":[{"internalType":"contractERC20","name":"depositAsset","type":"address"},{"internalType":"uint256","name":"depositAmount","type":"uint256"},{"internalType":"uint256","name":"minimumMint","type":"uint256"}],"name":"deposit","outputs":[{"internalType":"uint256","name":"shares","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"TellerWithMultiAssetSupport__DepositExceedsCap","type":"error"}]'


class TotalSupplyMonitor:
    def __init__(
            self,
            max_supply: int,
            total_accs: int,
            decimals: int = 18,
            check_interval: int = 5,
    ):
        self.check_interval = check_interval
        self.total_accs = total_accs

        self.decimals = decimals
        self.max_supply_value = int(max_supply * 10 ** decimals)

        self.listeners = []


    async def update_supply(self):
        try:
            contract = RPCInitializer.initialize_contract(
                chain_name="ethereum",
                address=VAULT_ADDRESS,
                abi=VAULT_ABI,
            )
            return await contract.functions.totalSupply().call()

        except Exception as e:
            logger.warning(f"[-] Web3 | Error getting current supply: {e}")
            return None


    def subscribe(self, listener):
        self.listeners.append(listener)
        if len(self.listeners) in [THREADS, self.total_accs]:
            logger.debug(f'[•] Web3 | Waiting for free supply...')


    def unsubscribe(self, listener):
        self.listeners.remove(listener)
        self.total_accs -= 1


    async def run(self):
        while True:
            new_supply = await self.update_supply()
            if new_supply:
                free_supply = self.max_supply_value - new_supply
                free_supply_amount = round(free_supply / 10 ** self.decimals, 2)

                if free_supply_amount > 0 and self.listeners:
                    logger.debug(f'[•] Web3 | Found free supply: {free_supply_amount}')

                    for listener in self.listeners:
                        await listener.put(free_supply)

            await asyncio.sleep(self.check_interval)


class Plasma(Wallet):
    def __init__(self, wallet: Wallet):
        super().__init__(
            privatekey=wallet.privatekey,
            encoded_pk=wallet.encoded_pk,
            db=wallet.db,
            browser=wallet.browser,
            recipient=wallet.recipient
        )

        self.from_chain = "ethereum"
        self.web3 = self.get_web3(self.from_chain)


    async def run(self, mode: int, monitor: TotalSupplyMonitor):
        deposit_token_name, token_info = await self.get_token_for_deposit()

        random_deposit_percent = uniform(*DEPOSIT_PERCENT) / 100
        if random_deposit_percent == 1:
            deposit_amount = round(token_info["amount"], 2)
            deposit_value = token_info["value"]

        else:
            deposit_amount = round(token_info["amount"] * random_deposit_percent, randint(0, 3))
            deposit_value = int(deposit_amount * 10 ** token_info["decimals"])

        approved = await self.approve(
            chain_name=self.from_chain,
            token_name=deposit_token_name,
            spender=VAULT_ADDRESS,
            value=deposit_value,
            decimals=monitor.decimals
        )

        if mode == 1:
            return await self.wait_for_supply(
                monitor=monitor,
                deposit_token_name=deposit_token_name,
                token_info=token_info,
                deposit_value=deposit_value,
            )

        elif mode == 2:
            if not approved:
                logger.debug(f'[•] Web3 | {self.address} | Already approved {deposit_amount} {deposit_token_name}')
                self.db.append_report(
                    privatekey=self.encoded_pk,
                    text=f"already approved {deposit_amount} {deposit_token_name}",
                    success=True,
                )

            return True


    async def get_token_for_deposit(self):
        tokens_balances = {
            token_name: await self.get_token_info(chain_name=self.from_chain, token_name=token_name)
            for token_name in TOKENS_TO_DEPOSIT
        }
        return max(tokens_balances.items(), key=lambda x: x[1]["value"])


    async def wait_for_supply(
            self,
            monitor: TotalSupplyMonitor,
            deposit_token_name: str,
            token_info: dict,
            deposit_value: int,
    ):
        listener = asyncio.Queue()
        monitor.subscribe(listener)

        logger.debug(f'[•] Web3 | {self.address} | Going to deposit {round(deposit_value / 10 ** token_info["decimals"], 2)} {deposit_token_name}')

        while True:
            try:
                free_supply = await listener.get()

                if deposit_value <= free_supply:
                    deposit_status = await self.deposit_token(deposit_token_name, token_info, deposit_value)
                    if deposit_status:
                        monitor.unsubscribe(listener)
                        return True

            except Exception as err:
                logger.error(f"[-] Web3 | {self.address} | Deposit failed: {err}")


    async def deposit_token(
            self,
            deposit_token_name: str,
            token_info: dict,
            deposit_value: int,
    ):
        try:
            deposit_contract = RPCInitializer.initialize_contract(
                chain_name=self.from_chain,
                address=DEPOSIT_ADDRESS,
                abi=DEPOSIT_ABI,
            )
            deposit_amount = round(deposit_value / 10 ** token_info["decimals"], 3)

            tx_label = f"deposit {deposit_amount} {deposit_token_name} in plasma"
            tx = deposit_contract.functions.deposit(
                token_info["address"],
                deposit_value,
                0
            )
            await self.sent_tx(
                chain_name=self.from_chain,
                tx=tx,
                tx_label=tx_label
            )
            return True

        except TransactionError as err:
            if (
                    not err.encoded_tx and
                    find_contract_error(
                        abi=deposit_contract.abi,
                        error_code=err.error_code
                    ) != "TellerWithMultiAssetSupport__DepositExceedsCap"
            ):
                logger.error(f'[-] Web3 | {self.address} | Deposit error: {err}')
            return False

        except Exception as err:
            logger.error(f'[-] Web3 | {self.address} | Deposit error: {err}')
            return False
