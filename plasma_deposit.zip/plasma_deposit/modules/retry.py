from settings import RETRY
from time import sleep

from loguru import logger

from requests.exceptions import JSONDecodeError as json_error1
from json.decoder import JSONDecodeError as json_error2


class CustomError(Exception): pass

class DataBaseError(Exception): pass

class OnetimeError(Exception): pass

class CfClearanceError(Exception): pass

class TransactionError(Exception):
    def __init__(self, message: str, error_code: str, encoded_tx: str = ""):
        error_string = f"{message}: {error_code}" + (f" | encoded tx: {encoded_tx}" if encoded_tx else "")
        super().__init__(error_string)
        self.error_code = error_code
        self.encoded_tx = encoded_tx


def have_json(func):
    def wrapper(*args, **kwargs):
        response = func(*args, **kwargs)
        try:
            response.json()
        except (json_error1, json_error2):
            error_msg = response.text[:350].replace("\n", " ")
            if "Just a moment..." in error_msg:
                raise CfClearanceError(f'Wrong cf-clearance')

            raise Exception(f'bad json response: {error_msg}')

        return response
    return wrapper


def retry(
        source: str,
        module_str: str = None,
        exceptions = Exception,
        retries: int = RETRY,
        not_except = (CustomError, CfClearanceError),
        infinity_errors_text: list = None,
        to_raise: bool = True,
        sleep_on_error: int = 2,
):
    def decorator(f):
        custom_module_str = f.__name__.replace('_', ' ').title() if not module_str else module_str
        def newfn(*args, **kwargs):
            attempt = 0
            while attempt < retries:
                try:
                    return f(*args, **kwargs)

                except not_except as e:
                    if to_raise: raise e.__class__(f'{custom_module_str}: {e}')
                    else: return False

                except exceptions as e:
                    attempt += 1

                    if infinity_errors_text and any([error_text in str(e) for error_text in infinity_errors_text]):
                        infinity_retries = 10

                        logger.warning(f'[-] {source} | {custom_module_str} | {e} [{attempt}/{infinity_retries}]')
                        if attempt == infinity_retries:
                            if to_raise: raise ValueError(f'{custom_module_str}: {e}')
                            else: return False

                    else:
                        logger.error(f'[-] {source} | {custom_module_str} | {e} [{attempt}/{retries}]')

                        if attempt == retries:
                            if to_raise: raise ValueError(f'{custom_module_str}: {e}')
                            else: return False

                    sleep(sleep_on_error)
        return newfn
    return decorator
